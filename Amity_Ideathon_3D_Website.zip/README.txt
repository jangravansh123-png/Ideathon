AMITY IDEATHON 3D WEBSITE
Open index.html in Chrome/Edge.

Includes:
- Three.js interactive 3D particle field
- CSS 3D hero planet and orbital rings
- Responsive premium UI
- Challenge, process, timeline, prizes and registration sections
- Demo registration form

The registration and prize values are sample UI content; replace with official event details before publishing.
Three.js is loaded from a CDN, so internet access is needed for the 3D background.
